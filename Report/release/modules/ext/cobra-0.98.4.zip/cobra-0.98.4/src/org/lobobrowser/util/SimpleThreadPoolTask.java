package org.lobobrowser.util;

public interface SimpleThreadPoolTask extends Runnable {
	public void cancel();
}
