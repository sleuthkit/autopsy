Please see http://html.xamjwg.org/cobra.jsp for
additional information on this toolkit.

See the LICENSE.txt file for Cobra licensing
and the COBRA-ACK.txt file for licensing 
information on Cobra dependencies.
